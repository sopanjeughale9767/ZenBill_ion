import { TermSearchPipe } from './term-search.pipe';

describe('TermSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new TermSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
