import { NumToWordPipe } from './num-to-word.pipe';

describe('NumToWordPipe', () => {
  it('create an instance', () => {
    const pipe = new NumToWordPipe();
    expect(pipe).toBeTruthy();
  });
});
