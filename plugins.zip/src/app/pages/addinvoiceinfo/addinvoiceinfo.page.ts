import { Component, OnInit } from '@angular/core';
import { ShareddataService } from 'src/app/services/shareddata.service';
import { HttpClient } from '@angular/common/http';
import { ConfigProvider } from 'src/app/providers/config/config';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-addinvoiceinfo',
  templateUrl: './addinvoiceinfo.page.html',
  styleUrls: ['./addinvoiceinfo.page.scss'],
})
export class AddinvoiceinfoPage implements OnInit {

  formData = {
    invoiceNumber: '',
    invoiceDate:'',
    custId: null,
    deliveryTerms: '',
    deliveryNote: '',
    paymentMode: '',
    supplierRef: '',
    otherRef: '',
    items: [],
    byersOrderNumber: '',
    byersDate: '',

    despatchThrough: '',
    destination: '',
    declaration: '',
    totalSgstAmount: 0,
    totalCgstAmount: 0,
    totalIgstAmount: 0,
    note:''
  }
  gst: string;
  templateNumber: string;

  constructor(
    public shared : ShareddataService,
    public httpClient : HttpClient,
    public config : ConfigProvider,
    public router : Router,
    public datepipe : DatePipe
  ) { 
    debugger
    this.httpClient.get(this.config.url + 'invoice/getInvoiceById/0').subscribe((data: any) => {
      this.formData.invoiceNumber = "INV/" + (data.result[0].total+1);
      this.shared.invoiceNumber = this.formData.invoiceNumber;

      this.formData.invoiceDate = this.datepipe.transform(new Date(),'yyyy-MM-dd');;
    });

    var cid = localStorage.getItem('companyId');
    this.shared.httpClient.get(this.config.url + 'company/getCompany/' + parseInt(cid)).subscribe((data: any) => {
      this.shared.companyData = data;
    });
  }

  ngOnInit() {
  }

  saveInvoice() {
    debugger
    this.gst = localStorage.getItem('custGst');
    

    if (this.gst.substring(0, 2) == this.shared.companyData.result[0].companyGstNo.substring(0, 2)) {
      this.shared.itemData.forEach(element=>{
        element.cgst=element.gst/2;
        element.sgst=element.gst/2;
        element.igst=0;
        
      })
    } else {
      this.shared.itemData.forEach(element=>{
        element.cgst=0;
        element.sgst=0;
        element.igst=element.gst;
      })
    }
    this.shared.presentLoading();
    this.formData.items = this.shared.itemData;
    
    this.formData.custId = this.shared.customerData.custId;
    this.httpClient.post(this.config.url + 'invoice/saveInvoice', this.formData).subscribe((data: any) => {
      if (data.status == true) {
        this.shared.invoiceData = data.result[0];
        localStorage.setItem('invoiceId',data.result[0].invoiceId);
        this.shared.presentSuccessToast(data.message);
        this.templateNumber = localStorage.getItem('number');
        if (parseInt(this.templateNumber) == 1) {
          this.router.navigateByUrl("/template1");
        } else {
          if (parseInt(this.templateNumber) == 2) {
            this.router.navigateByUrl("/template2");
          } else {
            if (parseInt(this.templateNumber) == 3) {
              this.router.navigateByUrl("/template3");
            } else {
              if (parseInt(this.templateNumber) == 4) {
                this.router.navigateByUrl("/home");
              } else {
                this.router.navigateByUrl("/home");
              }
            }
          }
        }
      } else {
        this.shared.presentDangerToast(data.message);
      }

    })
  }
}
