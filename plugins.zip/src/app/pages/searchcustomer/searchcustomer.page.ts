import { Component, OnInit } from '@angular/core';
import { ShareddataService } from 'src/app/services/shareddata.service';
import { HttpClient } from '@angular/common/http';
import { ConfigProvider } from 'src/app/providers/config/config';
import { Router } from '@angular/router';

@Component({
  selector: 'app-searchcustomer',
  templateUrl: './searchcustomer.page.html',
  styleUrls: ['./searchcustomer.page.scss'],
})
export class SearchcustomerPage implements OnInit {
  customers: any;
  isItemAvailable: boolean = false;

  constructor(
    public shared: ShareddataService,
    public httpClient: HttpClient,
    public config: ConfigProvider,
    public router: Router
  ) { }

  ngOnInit() {
    this.shared.presentLoading();
    var dat: { [k: string]: any } = {};
    dat.custid = localStorage.getItem('custId');;
    dat.companyId = localStorage.getItem('companyId');
    this.httpClient.post(this.config.url + 'customer/getAll', dat).subscribe((data: any) => {

      if (data.status == true) {
        this.isItemAvailable = true;
        this.customers = data.result;
        this.shared.presentSuccessToast(data.message);
      } else {
        this.shared.presentDangerToast(data.message);
      }
    });
  }

  getCustomer(ev: any) {

    const val = ev.target.value;
    if (val.replace(/\s/g, "").length < 1) {
      var dat: { [k: string]: any } = {};
      dat.custid = localStorage.getItem('custId');;
      dat.companyId = localStorage.getItem('companyId');
      this.httpClient.post(this.config.url + 'customer/getAll', dat).subscribe((data: any) => {
        this.customers = data.result;
      });
    } else {
      // this.shared.presentLoading();
      var dat: { [k: string]: any } = {};
      dat.key = val.toString()
      dat.companyId = localStorage.getItem('companyId');
      this.httpClient.post(this.config.url + 'customer/searchCustomer', dat).subscribe((data: any) => {
        if (data.status == true) {
          this.isItemAvailable = true;
          this.customers = data.result;
          console.log(data);
        } else {
          this.isItemAvailable = false;
          this.shared.presentDangerToast("data.message");
        }
      });
    }

  }

  getCustomerDetails(custId) {
    debugger
    var dat: { [k: string]: any } = {};
    dat.custId = custId;
    dat.companyId = localStorage.getItem('companyId');
    this.httpClient.post(this.config.url + 'customer/getCustomer', dat).subscribe((data: any) => {
      if (data.status == true) {
        this.shared.customerData = data.result[0];
        this.shared.customers = data.result[0];
        this.shared.showCard = true;
        localStorage.setItem('custGst', data.result[0].custGstNumber);
        localStorage.setItem('custId', data.result[0].custId);
        this.router.navigateByUrl('/addcustomer');
this.shared.presentSuccessToast(data.message);
      } else {
        this.shared.presentDangerToast(data.message);
      }
    });
  }

}
