import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ShareddataService } from 'src/app/services/shareddata.service';
import { HttpClient } from '@angular/common/http';
import { ConfigProvider } from 'src/app/providers/config/config';

@Component({
  selector: 'app-home1',
  templateUrl: './home1.page.html',
  styleUrls: ['./home1.page.scss'],
})
export class Home1Page implements OnInit {
  companyId: number;

  constructor(
    public router: Router,
    public shared: ShareddataService,
    public httpClient: HttpClient,
    public config: ConfigProvider
  ) {
    debugger
    // if (localStorage.getItem('companyId') != 'null') {
      this.companyId = parseInt(localStorage.getItem('companyId'));
      this.httpClient.get(this.config.url + 'company/getCompany/' + this.companyId).subscribe((data: any) => {
        if (data.status == true) {
          this.shared.companyData = data.result[0];

        } else {
          this.shared.presentDangerToast("Company Data not Found..");
        }
      })
    // } else {
    //   this.router.navigateByUrl('/login');
    // }
  }

  ngOnInit() {
    this.shared.customerData.companyId = parseInt(localStorage.getItem('companyId'));

  }

  onCustomer(bit) {
    debugger
    localStorage.setItem('gstBit', bit);
    if (bit == 1) {
      if (localStorage.getItem('gstNo') != '') {
        this.router.navigateByUrl('/addcustomer');
      } else {
        this.shared.presentAlert('Alert', 'GST number not enter when you registered your company...!');
      }
    } else {
      this.router.navigateByUrl('/addcustomer');
    }
    this.router.navigateByUrl('/addcustomer');
  }
}
