import { Injectable } from '@angular/core';
import { LoadingController, ToastController, AlertController, ActionSheetController, Platform } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { HttpClient } from '@angular/common/http';
import { ConfigProvider } from '../providers/config/config';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class ShareddataService {
  currentOpenedModel: any = null;
  public companyData: { [c: string]: any } = {};
  public invoiceData: { [i: string]: any } = {};
  public customerData: { [r: string]: any } = {};
  public invoiceItems = new Array;

  public customers = new Array;
  searchItem = new Array;
  showCard: boolean = false;
  itemData = new Array;
  itemMastersData = new Array;
  IsSubscibed = 0;
  public selectedFooterPage = "HomePage";
  invoiceNumber: any;
  isSearch:boolean=false;

  formData = {
    hsnCode: null,
    itemName: null,
    quantity: null,
    rate: null,
    unit: null,
    gst: null,
    discount: 0

  }
  
  constructor(
    public loading: LoadingController,
    public storage: Storage,
    public toastController: ToastController,
    public alertController: AlertController,
    public httpClient: HttpClient,
    public config: ConfigProvider,
    public actionSheetController: ActionSheetController,
    public platform: Platform,
    public router : Router
  ) {
    storage.get('customerData').then((val) => {
      if (val != null || val != undefined) {
        this.companyData = val;

      }
    });
  }




  async presentLoading() {
    const loading = await this.loading.create({
      message: 'Loading',
      spinner: 'bubbles',
      duration: 2000
    });
    await loading.present();
  }

  async presentLoadingWithtxt(txt) {
    const loading = await this.loading.create({
      message: txt,
      spinner: 'bubbles',
      duration: 2000
    });
    await loading.present();
  }

  hideLoading() {
    this.loading.dismiss().catch(() => { });
  }

  companyDetails(data) {
    debugger
    this.companyData = data;
    console.log(this.companyData);
    this.storage.set('companyData', this.companyData);
    localStorage.setItem('companyId', this.companyData.companyId);
    localStorage.setItem('gstNo', data.companyGstNo);
    // this.subscribePush();
  }
  logOut() {
    this.customerData = {};
    this.storage.set('companyData', this.companyData);
    localStorage.removeItem('companyId');
    localStorage.removeItem('custId');
    localStorage.removeItem('gstBit');
    localStorage.removeItem('gstNo');
    localStorage.removeItem('invoiceId');
    localStorage.removeItem('custGst');
    this.router.navigateByUrl('/login');
    // this.fb.logout();
  }


  async presentToast(txt) {
    const toast = await this.toastController.create({
      message: txt,
      duration: 2000,

    });
    toast.present();
  }

  async presentSuccessToast(txt) {
    const toast = await this.toastController.create({
      message: txt,
      duration: 2000,
      color: 'success'
    });
    toast.present();
  }

  async presentDangerToast(txt) {
    const toast = await this.toastController.create({
      message: txt,
      duration: 2000,
      color: "danger"
    });
    toast.present();
  }

  async presentAlert(tx, txt) {
    const alert = await this.alertController.create({
      header: tx,
      message: txt,
      buttons: ['OK']
    });

    await alert.present();
  }
}
